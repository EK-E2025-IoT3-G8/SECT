import time
import sys
from gpiozero import OutputDevice
from luma.core.interface.serial import i2c
from luma.core.render import canvas
from luma.oled.device import ssd1306
from ina219 import INA219
import smbus2
from rpi_ws281x import PixelStrip, Color

# --- Configuration ---
# I2C Configuration
I2C_PORT = 1
I2C_ADDR_OLED = 0x3C
I2C_ADDR_INA219 = 0x40 # Default
I2C_ADDR_ADS1115 = 0x48 # Default

# MOSFET Configuration
MOSFET_PIN = 24 # GPIO 24

# Resistance Measurement Configuration
R_REF = 10000.0 # Reference Resistor in Ohms (10k) - ADJUST THIS TO MATCH HARDWARE
V_IN = 3.3      # Input Voltage in Volts - ADJUST THIS TO MATCH HARDWARE
RESISTANCE_THRESHOLD = 5000.0 # 5k Ohm Threshold

# Neopixel Configuration
ENABLE_NEOPIXELS = False # Set to True ONLY if using GPIO 18 (PWM) on Pi 5
NEOPIXEL_PIN = 18 # GPIO 18 (PWM0)
LED_COUNT = 16
LED_BRIGHTNESS = 50 # 0-255

# --- ADS1115 Helper Class (Simple Implementation) ---
class ADS1115:
    def __init__(self, bus, address=0x48):
        self.bus = bus
        self.address = address

    def read_voltage(self, channel):
        # Config register: Single-ended, 4.096V range, 128 SPS
        # 1 100 (A0) 001 (4.096V) 0 (Continuous) 100 (128SPS) 0 0 1 1
        # MUX: 100=A0, 101=A1, 110=A2, 111=A3
        mux = {0: 0x4, 1: 0x5, 2: 0x6, 3: 0x7}
        if channel not in mux:
            return 0.0
            
        config = 0x8000 | (mux[channel] << 12) | (0x1 << 9) | (0x1 << 15)
        # Swap bytes for big-endian
        config_bytes = [(config >> 8) & 0xFF, config & 0xFF]
        
        try:
            self.bus.write_i2c_block_data(self.address, 1, config_bytes)
            time.sleep(0.01) # Wait for conversion
            
            result = self.bus.read_i2c_block_data(self.address, 0, 2)
            raw = (result[0] << 8) | result[1]
            if raw > 32767:
                raw -= 65536
            
            # 4.096V range / 32768 = 0.125mV per bit
            return raw * 0.000125
        except Exception as e:
            print(f"ADS1115 Read Error: {e}")
            return 0.0

def i2c_scan(bus):
    print("\nScanning I2C bus...")
    devices = []
    for addr in range(0x03, 0x78):
        try:
            bus.write_byte(addr, 0)
            devices.append(addr)
        except OSError:
            pass
    
    if devices:
        print("I2C devices found:", [hex(device_address) for device_address in devices])
    else:
        print("No I2C devices found")
    return devices

def main():
    print("Initializing IoT Device Test (Native Libs)...")

    # 1. Setup I2C
    try:
        bus = smbus2.SMBus(I2C_PORT)
        print(f"I2C bus {I2C_PORT} initialized.")
    except Exception as e:
        print(f"Error initializing I2C: {e}")
        return

    # 2. I2C Scan
    i2c_scan(bus)

    # 3. Initialize Components
    
    # OLED
    oled = None
    try:
        serial = i2c(port=I2C_PORT, address=I2C_ADDR_OLED)
        oled = ssd1306(serial)
        with canvas(oled) as draw:
            draw.text((0, 0), "IoT Test Init...", fill="white")
        print("OLED initialized.")
    except Exception as e:
        print(f"Warning: OLED not found or error: {e}")

    # INA219
    ina = None
    try:
        ina = INA219(SHUNT_OHMS=0.1, busnum=I2C_PORT, address=I2C_ADDR_INA219)
        ina.configure()
        print("INA219 initialized.")
    except Exception as e:
        print(f"Warning: INA219 not found or error: {e}")

    # ADS1115
    ads = None
    try:
        ads = ADS1115(bus, I2C_ADDR_ADS1115)
        print("ADS1115 initialized.")
    except Exception as e:
        print(f"Warning: ADS1115 not found or error: {e}")

    # MOSFET
    mosfet = None
    try:
        mosfet = OutputDevice(MOSFET_PIN, active_high=True, initial_value=False)
        print(f"MOSFET initialized on GPIO {MOSFET_PIN}.")
    except Exception as e:
        print(f"Error initializing MOSFET: {e}")

    # Neopixel
    strip = None
    if ENABLE_NEOPIXELS:
        try:
            # LED_PIN, LED_COUNT, LED_FREQ_HZ, LED_DMA, LED_INVERT, LED_BRIGHTNESS, LED_CHANNEL
            strip = PixelStrip(LED_COUNT, NEOPIXEL_PIN, 800000, 10, False, LED_BRIGHTNESS, 0)
            strip.begin()
            for i in range(strip.numPixels()):
                strip.setPixelColor(i, Color(0, 0, 0))
            strip.show()
            print(f"Neopixels initialized on GPIO {NEOPIXEL_PIN}.")
        except Exception as e:
            print(f"Error initializing Neopixels: {e}")
    else:
        print("Neopixels DISABLED (Enable in script if hardware supports it).")


    print("\nStarting Test Loop. Press Ctrl+C to exit.")
    
    # Turn MOSFET ON immediately
    if mosfet:
        mosfet.on()
        print("MOSFET turned ON.")

    try:
        while True:
            # --- Read Sensors ---
            print("-" * 20)
            
            # INA219
            bus_voltage = 0
            current = 0
            if ina:
                try:
                    bus_voltage = ina.voltage()
                    current = ina.current()
                    print(f"INA219: {bus_voltage:.2f}V, {current:.2f}mA")
                except Exception as e:
                    print(f"INA219 Read Error: {e}")

            # ADS1115 & Resistance Calculation
            ads_vals = []
            resistances = []
            status_colors = [] # For Neopixels

            if ads:
                try:
                    for i in range(4):
                        val = ads.read_voltage(i)
                        ads_vals.append(val)
                        
                        # Calculate Resistance
                        # V_out = V_in * (R_dut / (R_ref + R_dut))
                        # R_dut = R_ref * (V_out / (V_in - V_out))
                        r_val = 0.0
                        if val > 0 and val < V_IN:
                            r_val = R_REF * (val / (V_IN - val))
                        
                        resistances.append(r_val)
                        
                        # Determine Status
                        status = "BAD"
                        color = Color(255, 0, 0) # Red
                        if r_val < RESISTANCE_THRESHOLD and r_val > 0: # Check > 0 to avoid open circuit being "good" if logic inverted, but here < 5k is good.
                             # Actually, usually low resistance = good connection.
                             status = "GOOD"
                             color = Color(0, 255, 0) # Green
                        
                        status_colors.append(color)
                        
                        print(f"Ch{i}: {val:.3f}V | {r_val:.1f} Ohm | {status}")

                except Exception as e:
                    print(f"ADS Read Error: {e}")

            # --- Update Neopixels ---
            if strip and ENABLE_NEOPIXELS:
                try:
                    for i in range(4): # Map Ch0-3 to Pixel 0-3
                        if i < len(status_colors):
                            strip.setPixelColor(i, status_colors[i])
                        else:
                            strip.setPixelColor(i, Color(0,0,0))
                    strip.show()
                except Exception as e:
                    print(f"Neopixel Error: {e}")

            # --- Update OLED ---
            if oled:
                try:
                    with canvas(oled) as draw:
                        draw.text((0, 0), "MOSFET: ON", fill="white")
                        if len(resistances) >= 4:
                            # Show 4 resistances in a grid
                            draw.text((0, 10), f"R1:{resistances[0]/1000:.1f}k R2:{resistances[1]/1000:.1f}k", fill="white")
                            draw.text((0, 20), f"R3:{resistances[2]/1000:.1f}k R4:{resistances[3]/1000:.1f}k", fill="white")
                        
                        if ina:
                            draw.text((0, 35), f"V:{bus_voltage:.2f}V I:{current:.1f}mA", fill="white")
                except Exception as e:
                    print(f"OLED Update Error: {e}")

            time.sleep(1.0)

    except KeyboardInterrupt:
        print("\nExiting...")
        if mosfet:
            mosfet.off()
        if strip and ENABLE_NEOPIXELS:
            for i in range(strip.numPixels()):
                strip.setPixelColor(i, Color(0, 0, 0))
            strip.show()
        if oled:
            oled.clear()

if __name__ == "__main__":
    main()
